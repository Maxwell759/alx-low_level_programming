0. _putchar
1. I sometimes suffer from insomnia. And when I can't fall asleep, I play what I call the alphabet game
2. 10 x alphabet
3. islower
4. isalpha
5. Sign
There is no such thing as absolute value in this world. You can only estimate what a thing is worth to you
7. There are only 3 colors, 10 digits, and 7 notes; it's what we do with them that's important
8. I'm federal agent Jack Bauer, and today is the longest day of my life
9. Learn your times table
10. a + b
11. 98 Battery Street, the OG
