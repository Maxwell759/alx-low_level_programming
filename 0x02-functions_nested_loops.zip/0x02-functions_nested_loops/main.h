/**
 * *File:main.h
 * *Author:Maxwell 
 * *Desc:header file containing functions declaration
 * */

void print_alphabet(void);
void jack_bauer(void);
void print_alphabet_x10(void);
void times_table();
void print_to_98(int);
void print_times_table(int);
int _putchar(char);
int _islower(int c);
int _isalpha(int c);
int print_sign(int n);
int _abs(int);
int add(int n, int m);
int print_last_digit(int n);
void num(int r, int n);
