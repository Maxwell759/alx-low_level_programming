#include "main.h"
/**
*add - sums up two numbers
*@n:first integer
*@m:second integer
*Return: returns 0
*/
int add(int n, int m)
{
return (n + m);
}
